# Detection Rule: Suspicious PowerShell Activity

## Objective
Identify PowerShell activity with characteristics that warrant Tier 1 investigation.

## Recommended Data Sources
- Sysmon Event ID 1
- Windows PowerShell Operational logs
- PowerShell Script Block Logging, where enabled

## Starter SPL

```spl
index=windows (EventCode=1 OR source="WinEventLog:Microsoft-Windows-PowerShell/Operational")
| eval cmd=coalesce(CommandLine, Message, process)
| search cmd="*powershell*"
| eval suspicious=if(match(lower(cmd), "-enc|-encodedcommand|downloadstring|invoke-webrequest|frombase64string|bypass|hidden"), "yes", "review")
| table _time host User ParentImage Image cmd suspicious
| sort - _time
```

## MITRE ATT&CK
Potential mappings depend on the observed command. Do not map automatically without supporting evidence.

## Analyst Checks
- User and host
- Parent process
- Full command line
- Encoded or obfuscated content
- Network connections
- File creation
- Whether activity was approved administration

## Expected False Positives
- IT automation
- Software deployment
- Administrative scripts
- Security testing
