# Detection Rule: Privileged Group Membership Change

## Objective
Detect additions to or removals from privileged Active Directory groups.

## Data Sources
Common Windows Security events may include 4728, 4729, 4732, 4733, 4756, and 4757 depending on group type.

## Starter SPL

```spl
index=windows EventCode IN (4728,4729,4732,4733,4756,4757)
| eval actor=coalesce(SubjectUserName, user)
| eval member=coalesce(MemberName, TargetUserName)
| eval group=coalesce(TargetUserName, GroupName)
| table _time host EventCode actor member group
| sort - _time
```

## Analyst Checks
- Who made the change?
- Which account was affected?
- Which group was modified?
- Was there an approved change ticket?
- Did the new member authenticate or perform administrative actions afterward?

## MITRE ATT&CK
Map only when the activity is unauthorized and the evidence supports persistence or privilege escalation behavior.
