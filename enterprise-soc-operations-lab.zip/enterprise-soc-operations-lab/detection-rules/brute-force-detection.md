# Detection Rule: Repeated Authentication Failures

## Objective
Detect repeated Windows authentication failures that may indicate brute-force activity, password guessing, or a misconfigured service.

## Data Source
- Windows Security Event ID 4625
- Optional correlation with Event ID 4624

## Starter SPL

```spl
index=windows EventCode=4625
| eval account=coalesce(Account_Name, TargetUserName, user)
| eval source_ip=coalesce(Source_Network_Address, IpAddress, src_ip)
| stats count earliest(_time) as first_seen latest(_time) as last_seen values(Failure_Reason) as failure_reasons by account source_ip host
| where count >= 5
| convert ctime(first_seen) ctime(last_seen)
| sort - count
```

## Correlation Search for Success After Failures

```spl
index=windows (EventCode=4625 OR EventCode=4624)
| eval account=coalesce(Account_Name, TargetUserName, user)
| eval source_ip=coalesce(Source_Network_Address, IpAddress, src_ip)
| stats count(eval(EventCode=4625)) as failures count(eval(EventCode=4624)) as successes earliest(_time) as first_seen latest(_time) as last_seen by account source_ip host
| where failures >= 5
| convert ctime(first_seen) ctime(last_seen)
| sort - failures
```

## MITRE ATT&CK
- T1110: Brute Force
- Use a sub-technique only when the observed pattern supports it.

## Expected False Positives
- Forgotten passwords
- Stale mapped drives
- Misconfigured services
- Cached credentials
- Approved password testing

## Analyst Checks
1. Confirm the account and source.
2. Review failure reason and logon type.
3. Check for successful authentication after failures.
4. Determine whether the account is privileged.
5. Compare timing with expected activity.
6. Review nearby endpoint and network events.

## Tuning Record
- Initial threshold: TODO
- Observed false positives: TODO
- Revised threshold or exclusions: TODO
- Reason for change: TODO
