# Project Completion Checklist

## Foundation
- [ ] Repository created
- [ ] Architecture diagram updated
- [ ] Asset inventory verified
- [ ] Splunk receives Windows logs
- [ ] Sysmon installed and verified
- [ ] Lab network isolated

## Case 1: Authentication
- [ ] Detection tested
- [ ] Evidence collected
- [ ] Report completed
- [ ] Verdict justified
- [ ] MITRE mapping supported
- [ ] Runbook completed

## Case 2: Phishing
- [ ] Sanitized sample selected
- [ ] Headers analyzed
- [ ] IOCs extracted
- [ ] Verdict justified
- [ ] Playbook completed

## Case 3: PowerShell
- [ ] Safe test activity generated
- [ ] Process evidence collected
- [ ] Detection tested
- [ ] Report completed

## Case 4: Privileged Change
- [ ] Authorized or simulated change generated
- [ ] AD event collected
- [ ] Approval context documented
- [ ] Report completed

## Case 5: False Positive
- [ ] Benign trigger selected
- [ ] Alternative explanations evaluated
- [ ] Tuning proposal documented

## Vulnerability Management
- [ ] Scan authorized and completed
- [ ] Findings validated
- [ ] Priority justified
- [ ] Remediation applied
- [ ] Verification scan completed

## Final Portfolio
- [ ] No TODO fields remain in completed cases
- [ ] Screenshots are redacted
- [ ] Metrics updated
- [ ] README links to strongest evidence
- [ ] Resume bullets use only verified results
