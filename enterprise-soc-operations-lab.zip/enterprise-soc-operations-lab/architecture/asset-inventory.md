# Asset Inventory

| Asset ID | Hostname | Owner/Role | Operating System | Criticality | Logging Source | Notes |
|---|---|---|---|---|---|---|
| AST-001 | NS-DC01 | Identity services | Windows Server | Critical | Windows Security, Sysmon | Domain controller |
| AST-002 | NS-WKS01 | Employee endpoint | Windows 11 | Medium | Windows Security, Sysmon | Standard user system |
| AST-003 | NS-WKS02 | Administrative endpoint | Windows 11 | High | Windows Security, Sysmon | Privileged access |
| AST-004 | NS-LNX01 | Application server | Ubuntu Linux | High | Syslog/auth logs | Server telemetry |
| AST-005 | NS-SIEM01 | Security monitoring | Splunk Enterprise | Critical | Splunk internal logs | SIEM |
| AST-006 | NS-TEST01 | Security testing | Isolated Linux VM | Low | Test logs | Safe simulation only |

## Accounts

| Account | Role | Privilege Level | Expected Behavior |
|---|---|---|---|
| jdoe | Standard employee | Standard | Business-hours workstation access |
| asmith | Finance employee | Standard | Finance workstation access |
| itadmin | IT administrator | Privileged | Approved administrative work |
| svc_backup | Backup service | Service account | Scheduled noninteractive activity |

## Data Handling

All names are fictional. Replace or expand the inventory only with sanitized lab information.
