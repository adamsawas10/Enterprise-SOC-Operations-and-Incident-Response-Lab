# Network Diagram Source

Use this Mermaid diagram in GitHub or recreate it in draw.io.

```mermaid
flowchart LR
    TEST[NS-TEST01\nIsolated Test VM] --> WKS1[NS-WKS01\nEmployee Workstation]
    TEST --> LNX[NS-LNX01\nUbuntu Server]
    WKS1 --> DC[NS-DC01\nDomain Controller]
    WKS2[NS-WKS02\nAdmin Workstation] --> DC
    WKS1 --> SIEM[NS-SIEM01\nSplunk]
    WKS2 --> SIEM
    DC --> SIEM
    LNX --> SIEM
    VSCAN[Nessus/OpenVAS] --> WKS1
    VSCAN --> LNX
```
