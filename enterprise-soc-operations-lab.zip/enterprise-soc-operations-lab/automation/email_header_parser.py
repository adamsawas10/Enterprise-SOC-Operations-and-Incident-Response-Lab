#!/usr/bin/env python3
"""Extract common investigation fields from a saved RFC 5322 email file.

This utility performs local parsing only. It does not submit data to external
services and does not determine whether an email is malicious.
"""

from __future__ import annotations

import argparse
import re
import sys
from email import policy
from email.parser import BytesParser
from pathlib import Path
from urllib.parse import urlparse

URL_RE = re.compile(r"https?://[^\s<>\"']+", re.IGNORECASE)


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract headers and URLs from an .eml file")
    parser.add_argument("email_file", type=Path, help="Path to a sanitized .eml file")
    args = parser.parse_args()

    if not args.email_file.exists():
        print(f"Error: file not found: {args.email_file}", file=sys.stderr)
        return 2

    with args.email_file.open("rb") as handle:
        message = BytesParser(policy=policy.default).parse(handle)

    print(f"Subject: {message.get('subject', '')}")
    print(f"From: {message.get('from', '')}")
    print(f"Reply-To: {message.get('reply-to', '')}")
    print(f"Return-Path: {message.get('return-path', '')}")
    print(f"Date: {message.get('date', '')}")
    print(f"Message-ID: {message.get('message-id', '')}")

    auth_results = message.get_all("authentication-results", [])
    if auth_results:
        print("\nAuthentication-Results:")
        for value in auth_results:
            print(f"- {value}")

    bodies: list[str] = []
    if message.is_multipart():
        for part in message.walk():
            if part.get_content_type() in {"text/plain", "text/html"}:
                try:
                    bodies.append(part.get_content())
                except Exception:
                    continue
    else:
        try:
            bodies.append(message.get_content())
        except Exception:
            pass

    urls = sorted(set(URL_RE.findall("\n".join(bodies))))
    print("\nURLs:")
    for url in urls:
        domain = urlparse(url).hostname or ""
        print(f"- {url}  [domain={domain}]")

    print("\nAttachments:")
    attachments = [part.get_filename() for part in message.iter_attachments()]
    if attachments:
        for name in attachments:
            print(f"- {name or '[unnamed attachment]'}")
    else:
        print("- None")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
