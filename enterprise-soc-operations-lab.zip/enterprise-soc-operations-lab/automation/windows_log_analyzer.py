#!/usr/bin/env python3
"""Analyze exported Windows authentication events from a CSV file.

Expected columns can vary. The script attempts to recognize common names for
timestamp, event ID, account, source IP, and host. It summarizes failed logins
and flags account/source combinations meeting a user-defined threshold.
"""

from __future__ import annotations

import argparse
import csv
import sys
from collections import Counter
from pathlib import Path

ALIASES = {
    "timestamp": ["_time", "timestamp", "time", "TimeCreated"],
    "event_id": ["EventCode", "event_id", "EventID", "Id"],
    "account": ["Account_Name", "TargetUserName", "user", "account"],
    "source_ip": ["Source_Network_Address", "IpAddress", "src_ip", "source_ip"],
    "host": ["host", "Computer", "computer_name"],
}


def choose_field(fieldnames: list[str], candidates: list[str]) -> str | None:
    lowered = {name.lower(): name for name in fieldnames}
    for candidate in candidates:
        if candidate.lower() in lowered:
            return lowered[candidate.lower()]
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="Summarize Windows failed logon events from CSV")
    parser.add_argument("csv_file", type=Path, help="CSV exported from Splunk or Event Viewer")
    parser.add_argument("--threshold", type=int, default=5, help="Failure count to flag (default: 5)")
    args = parser.parse_args()

    if not args.csv_file.exists():
        print(f"Error: file not found: {args.csv_file}", file=sys.stderr)
        return 2

    with args.csv_file.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            print("Error: CSV has no header row", file=sys.stderr)
            return 2

        fields = {key: choose_field(reader.fieldnames, aliases) for key, aliases in ALIASES.items()}
        missing = [key for key in ("event_id", "account", "source_ip") if not fields[key]]
        if missing:
            print(f"Error: required fields not recognized: {', '.join(missing)}", file=sys.stderr)
            print(f"Available columns: {', '.join(reader.fieldnames)}", file=sys.stderr)
            return 2

        failures: Counter[tuple[str, str, str]] = Counter()
        rows_seen = 0
        for row in reader:
            rows_seen += 1
            event_id = (row.get(fields["event_id"] or "") or "").strip()
            if event_id != "4625":
                continue
            account = (row.get(fields["account"] or "") or "UNKNOWN").strip()
            source_ip = (row.get(fields["source_ip"] or "") or "UNKNOWN").strip()
            host = (row.get(fields["host"] or "") or "UNKNOWN").strip() if fields["host"] else "UNKNOWN"
            failures[(account, source_ip, host)] += 1

    print(f"Rows reviewed: {rows_seen}")
    print("\nFlagged account/source combinations:")
    flagged = 0
    for (account, source_ip, host), count in failures.most_common():
        if count >= args.threshold:
            flagged += 1
            print(f"- account={account} source_ip={source_ip} host={host} failures={count}")

    if not flagged:
        print(f"None met threshold {args.threshold}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
