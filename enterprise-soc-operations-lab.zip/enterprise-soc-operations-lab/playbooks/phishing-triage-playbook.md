# Phishing Triage Playbook

## Intake
- Preserve the original email safely.
- Record sender, recipient, subject, timestamp, and reporting source.
- Do not open unknown attachments on a production system.

## Analysis
1. Review From, Reply-To, Return-Path, and Received headers.
2. Review SPF, DKIM, and DMARC results when available.
3. Compare display name and sender domain.
4. Extract URLs, domains, IP addresses, hashes, and attachment names.
5. Inspect URL structure and redirect behavior safely.
6. Review reputation and sandbox results using approved services.
7. Identify credential-harvesting, spoofing, urgency, impersonation, or malicious attachment indicators.
8. Determine whether any user clicked, replied, downloaded, or entered credentials.

## Verdicts
- Malicious
- Suspicious
- Benign
- Inconclusive

## Escalation Triggers
- Credential submission
- Malware execution
- Multiple recipients
- Executive or finance impersonation
- Confirmed malicious infrastructure

## Recommended Response
- Block sender/domain/URL as appropriate
- Remove messages from mailboxes
- Reset credentials and revoke sessions when exposed
- Investigate endpoints for follow-on activity
- Notify affected users
