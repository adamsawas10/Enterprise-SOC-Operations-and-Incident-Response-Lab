# Authentication Alert Runbook

## Purpose
Provide a repeatable Tier 1 process for investigating repeated failed logins and related authentication alerts.

## Procedure

1. Record the alert time, detection name, affected host, account, and source IP.
2. Confirm the raw authentication events exist.
3. Count failures and identify the time window.
4. Review failure reason and logon type.
5. Search for successful logins before and after the failures.
6. Determine whether the account is privileged, disabled, shared, or a service account.
7. Check whether the source is expected for the user or asset.
8. Review nearby endpoint, process, network, and account-change events.
9. Compare activity with maintenance, testing, and user-support records.
10. Assign a verdict and confidence level.
11. Assign severity based on impact and evidence.
12. Escalate confirmed or high-risk cases; close documented benign activity.
13. Record recommended containment and remediation.
14. Tune the detection only when the change does not create unacceptable blind spots.

## Escalation Triggers
- Successful login after repeated failures
- Privileged or sensitive account targeted
- Multiple accounts targeted
- Suspicious external source
- Endpoint or process evidence of compromise
- Account changes or lateral movement after authentication

## Suggested Containment
- Disable or reset affected credentials when compromise is credible
- Block malicious source indicators where appropriate
- Isolate affected endpoint when follow-on activity is observed
- Preserve logs and evidence
