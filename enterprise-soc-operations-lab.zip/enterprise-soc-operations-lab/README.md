# Enterprise SOC Operations and Incident Response Lab

## Executive Summary

This project simulates Tier 1 Security Operations Center work for the fictional organization **Northstar Financial Services**. The lab is designed to demonstrate alert monitoring, SIEM investigation, phishing analysis, identity monitoring, vulnerability management, MITRE ATT&CK mapping, escalation decisions, documentation, and basic analyst automation.

The project builds on prior hands-on work with Splunk, Windows Security logs, phishing analysis, Active Directory, Ubuntu Linux, Nmap, and Python. Evidence-specific values such as timestamps, IP addresses, usernames, screenshots, alert counts, and final verdicts must be replaced with results collected from the actual lab.

## Core Analyst Workflow

1. Generate or ingest safe test activity.
2. Collect and normalize telemetry.
3. Detect suspicious behavior.
4. Validate the alert.
5. Correlate identity, endpoint, email, network, and vulnerability evidence.
6. Assign severity.
7. Escalate, contain, remediate, or close.
8. Document the case and tune the detection.

## Environment

| Asset | Purpose | Suggested OS/Platform |
|---|---|---|
| NS-DC01 | Domain controller and identity source | Windows Server |
| NS-WKS01 | Standard employee workstation | Windows 11 |
| NS-WKS02 | Administrative workstation | Windows 11 |
| NS-LNX01 | Linux application server | Ubuntu Linux |
| NS-SIEM01 | Centralized log monitoring | Splunk Enterprise |
| NS-TEST01 | Isolated test system | Ubuntu/Kali-style test VM |

## Planned Investigations

| Case | Scenario | Primary Skills |
|---|---|---|
| INC-001 | Repeated authentication failures | Splunk, Windows Event Logs, alert triage |
| INC-002 | Phishing email | Header analysis, IOC extraction, documentation |
| INC-003 | Suspicious PowerShell | Sysmon, process analysis, escalation |
| INC-004 | Privileged account change | Active Directory, identity monitoring |
| INC-005 | Benign administrative activity | False-positive validation and tuning |
| VULN-001 | Vulnerability assessment and remediation | CVE/CVSS, prioritization, rescanning |

## Repository Structure

```text
enterprise-soc-operations-lab/
├── architecture/
├── detection-rules/
├── incident-cases/
├── vulnerability-management/
├── playbooks/
├── automation/
├── soc-metrics/
└── screenshots/
```

## Current Status

- [ ] Architecture diagram completed
- [ ] Asset inventory verified
- [ ] Splunk data sources connected
- [ ] INC-001 completed
- [ ] INC-002 completed
- [ ] INC-003 completed
- [ ] INC-004 completed
- [ ] INC-005 completed
- [ ] Vulnerability remediation cycle completed
- [ ] Final metrics report completed

## Portfolio Rules

- Do not publish real credentials, personal data, API keys, private IP details that expose a real environment, or unredacted email samples.
- Do not claim an incident was malicious unless the evidence supports that conclusion.
- Do not report simulated activity as a real-world attack.
- Replace every `TODO` field with observed evidence before presenting the case as complete.
- Keep screenshots readable and explain why each one matters.

## Resume-Ready Project Description

Use only after the corresponding work is completed and verified:

> Built and operated a virtual enterprise SOC environment centralizing Windows, Active Directory, Linux, email, and vulnerability telemetry for alert monitoring and Tier 1 investigation. Developed and tested SIEM detections, investigated simulated security cases, mapped supported activity to MITRE ATT&CK, documented escalation and containment recommendations, and tracked vulnerability remediation through verification scans.
