# Screenshot Guidance

Create subfolders by case, for example:

```text
screenshots/INC-001/
screenshots/INC-002/
```

For every image:
- Use a descriptive filename.
- Redact credentials, tokens, personal data, and unrelated information.
- Add a caption in the incident report explaining what the image proves.
- Prefer evidence screenshots over decorative screenshots.
