# SOC Investigation Metrics

| Metric | Value | Measurement Notes |
|---|---:|---|
| Alerts reviewed | 0 | Count only completed reviews |
| True positives | 0 | Evidence-supported malicious or unauthorized activity |
| Benign true positives | 0 | Rule fired correctly on approved/benign activity |
| False positives | 0 | Detection logic incorrectly flagged activity |
| Cases escalated | 0 | Cases requiring higher-tier review |
| Cases closed | 0 | Cases with documented closure |
| Mean investigation time | 0 minutes | Use start-to-decision time consistently |
| Detection rules created | 0 | Tested rules only |
| Detection rules tuned | 0 | Changes with documented reason |
| Vulnerabilities identified | 0 | Validated findings |
| Vulnerabilities remediated | 0 | Verified by rescan |

## Weekly Analyst Summary Template

### What happened
TODO

### Highest-risk case
TODO

### Detection quality
TODO

### Vulnerability status
TODO

### Priorities for next week
TODO
