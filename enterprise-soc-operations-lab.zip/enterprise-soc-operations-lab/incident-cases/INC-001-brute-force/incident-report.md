# INC-001: Repeated Authentication Failures

## Incident Summary
Investigate repeated Windows authentication failures against a user account and determine whether the activity is malicious, misconfigured, or user-driven. Prior work recorded 618 Windows Security events and six detected events; verify the exact meaning of those figures before using them in the final report.

## Initial Alert
- Alert source: TODO
- Alert time: TODO
- Detection rule: TODO
- Initial severity: TODO

## Affected Assets and Accounts
- Host(s): TODO
- User account(s): TODO
- Source IP/domain: TODO

## Evidence Collected
| Timestamp | Source | Evidence | Why It Matters |
|---|---|---|---|
| TODO | TODO | TODO | TODO |

## Investigation Timeline
| Time | Analyst Action | Finding |
|---|---|---|
| TODO | TODO | TODO |

## Analysis
Explain what happened, how the evidence connects, and what alternative benign explanations were considered.

## Verdict
- Classification: TODO — True Positive / Benign True Positive / False Positive / Inconclusive
- Confidence: TODO — Low / Medium / High
- Justification: TODO

## Severity Classification
- Final severity: TODO
- Business impact: TODO
- Reasoning: TODO

## MITRE ATT&CK Mapping
- Technique: TODO
- Evidence supporting mapping: TODO

## Escalation Decision
- Escalated: TODO — Yes / No
- Destination: TODO
- Reason: TODO

## Recommended Containment
- TODO

## Recommended Remediation
- TODO

## Final Status
- Status: TODO — Open / Escalated / Contained / Closed
- Closure reason: TODO

## Lessons Learned
- Detection improvement: TODO
- Process improvement: TODO
- Data gap: TODO
