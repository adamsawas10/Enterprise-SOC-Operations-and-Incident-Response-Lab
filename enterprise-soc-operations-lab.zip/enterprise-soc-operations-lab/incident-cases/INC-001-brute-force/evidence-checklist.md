# INC-001 Evidence Checklist

- [ ] Screenshot of raw Event ID 4625 event
- [ ] Screenshot of SPL results
- [ ] Count of failures by account
- [ ] Count of failures by source IP
- [ ] Timeline chart
- [ ] Search for Event ID 4624 after failures
- [ ] Logon type and failure reason
- [ ] Privileged-account check
- [ ] Source classification: internal/external/lab
- [ ] Final verdict and severity
- [ ] Escalation or closure notes
